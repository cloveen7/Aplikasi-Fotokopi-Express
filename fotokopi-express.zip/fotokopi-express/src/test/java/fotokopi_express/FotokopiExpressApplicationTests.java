package fotokopi_express;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FotokopiExpressApplicationTests {

	@Test
	void contextLoads() {
	}

}
